export type BankDTO = {
  code: number;
  name: string;
  fullName: string;
  ispb: string;
};
